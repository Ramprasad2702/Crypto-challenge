
Overview :

"Errors are not always your enemy—they can whisper the truth if you listen closely."

Endpoints :

Use /get_ciphertext to get IV and ciphertext.

Use /decrypt POST method only to check padding.

Include header: X-API-Key: s3cr3t-token.

GET requests to /decrypt will not work.
